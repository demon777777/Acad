package contacts;


public class Main {
    static String y;

    public static void main(String[] args) throws InterruptedException {
        new Enter();
    }


}
