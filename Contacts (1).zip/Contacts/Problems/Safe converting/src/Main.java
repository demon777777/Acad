import java.util.Scanner;

public class Main {
    /**
     Реализуйте метод для преобразования Long значения в int(примитивный тип) в соответствии со следующими правилами:
     если заданное значение является null методом, оно должно вернуть значение по умолчанию для int;
     если заданное значение больше, чем Integer.MAX_VALUE метод должен вернуть максимальное значение для int;
     если данное значение меньше, чем Integer.MIN_VALUE метод должен вернуть минимальное значение для целых чисел;
     в противном случае метод должен возвращать то же значение, что и переданный аргумент.
     */
    public static int convert(Long val) {
        if(val == null){
        return 0;
        }if(val > Integer.MAX_VALUE){
            return Integer.MAX_VALUE;
        }if(val < Integer.MIN_VALUE){
            return Integer.MIN_VALUE;
        }else {
            return val.intValue();
        }
    }

    /* Do not change code below */
    public static void main(String[] args) {
        Long val = new Long ("4321");

        Long val2 = Long.parseLong ("4321");

        Long val3 = 4321L;

        Long val4 = new Long (4321);
        System.out.println(val);
        System.out.println(val2);
        System.out.println(val3);
        System.out.println(val4);
    }
}