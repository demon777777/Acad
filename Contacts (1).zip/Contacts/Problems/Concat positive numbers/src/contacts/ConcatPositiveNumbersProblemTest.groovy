package contacts

class Test{
    public static ArrayList<Integer> concatPositiveNumbers(ArrayList<Integer> l1,
                                                           ArrayList<Integer> l2) {

        for(int i = 0;i<l1.size();i++){
            if (l2.get(i) < 0){
                return null;
            }else {
                return l1;
            }

        }
        for(int i = 0;i<l2.size();i++){
            if (l2.get(i) < 0){
                return null;
            }else {
                return l2;
            }
        }
        ArrayList<Integer>plus = new ArrayList<>(l1);
        plus.addAll(l2);

        return System.out.println(plus); // write your code here
    }
}
