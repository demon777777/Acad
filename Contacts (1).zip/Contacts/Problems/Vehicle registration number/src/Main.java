import java.util.Scanner;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println
                (new Scanner(System.in).nextLine().matches("^([01]\\d|2[0-3]):[0-5]\\d$") ? "YES" : "NO");
    }
}
