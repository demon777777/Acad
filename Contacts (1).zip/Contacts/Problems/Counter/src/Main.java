class Counter {

   static int current;

  static void plus(){
       current =+1;
   }
  static int getCurrent(){
       return current;
   }

    public static void main(String[] args) {
        plus();
        System.out.println(getCurrent());
    }
}