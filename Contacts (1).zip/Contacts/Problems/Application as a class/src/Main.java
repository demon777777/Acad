
class Application {
    public static void main(String[] args) {
        Incaps account = new Incaps();

     account.setId(1000);
     account.setCode("62968503812");
     account.setBalance(100_000_000);
     account.setEnabled(true);
      System.out.println(account.getId());      // 1000
     System.out.println(account.getCode());    // 62968503812
     System.out.println(account.getBalance()); // 100000000
     System.out.println(account.isEnabled());  // true
    }
}