import java.util.Objects;
import java.util.Scanner;
import java.util.Locale;

public class Main {
    /**
     Взгляните на метод, который принимает строку,
     преобразует все символы строки в верхний регистр и затем возвращает полученную строку.

     Но существует проблема. Иногда входная строка null.
     Как вы уже знаете, в этом случае метод выбрасывает NullPointerException.

     Ваша задача - исправить метод, чтобы избежать NPE .

     Если входная строка null, метод должен вернуть пустую строку "".
     */
    /* Fix this method */
    public static String toUpperCase(String str) {
if(str != null) {
    return str.toUpperCase(Locale.ENGLISH);
}else
    return " ";
    }

    /* Do not change code below */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        line = "none".equalsIgnoreCase(line) ? null : line;

            System.out.println(toUpperCase(line));
    }
}