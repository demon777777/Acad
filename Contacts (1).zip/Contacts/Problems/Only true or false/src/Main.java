public static boolean toPrimitive(Boolean b){
if(b != null){
    boolean f = b;
    return f;
        }else
return false;

        }