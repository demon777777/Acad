/**
 Вас попросили помочь с программированием на Java для пироговой компании.
 В настоящее время они пекут пироги, пирожные и пироги и
 упаковывают их в красивые коробки для продажи. К сожалению, их подход к программированию блоков довольно
 устарел, и для каждого типа круговых диаграмм требуется свой класс блоков. Этот подход плохо
 масштабируется и превратит ситуацию в кошмар с ростом ассортимента продукции (представьте себе все это:
 ApplePieBox, StrawberryPieBox и т. Д.).

 Чтобы избежать этого, реализуйте универсальный класс Box, который будет приспосабливать что-либо к
 методам put и возвращать его с помощью методов get .
*/

class Box<T,U,V> {

    /**
     * Поле "некоторого типа"
     */
    private T t;
    private U u;
    private V v;

    public U getU() {
        return u;
    }

    public U putU(U u) {
      U uu = u;
      return uu;
    }

    public V getV() {
        return v;
    }

    public V putV(V v) {
       V vari = v;
       return vari;
    }



    /**
     * Принимает значение «некоторый тип» и устанавливает его в поле
     */
    public Box(T t,U u,V v) {
        this.t = t;
        this.u = u;
        this.v = v;
    }

    /**
     * Возвращает значение "некоторого типа"
     */
    public T get() {
        return t;
    }

    /**
     * Принимает значение «некоторого типа», присваивает его переменной, а затем возвращает его
     */
    public T put(T parameter) {
        T variable = parameter;
        return variable;
    }

//    public static void main(String[] args) {
//        var box = new Box<>("Sukkkaaaaa");
//        var box2 = new Box<>(700000000);
//        System.out.println(box2.put(99999) + " , " + box2.get());
//    }
}