import java.util.*;
import java.util.regex.Pattern;

/**
 * Пароль трудно взломать, если он содержит хотя бы одну заглавную букву,
 * хотя бы одну строчную букву, хотя бы одну цифру и содержит 12 или более символов.
 * Для данной строки вы должны вывести «YES», если этот пароль трудно взломать,
 * в противном случае выведите «NO».
 *  Sample Input 1:
 * Password1234
 * Пример вывода 1:
 ДА
 * Пример ввода 2:
 SuperSecretPass
 * Пример вывода 2:
 НЕТ
 */
public class Main {

    public static void main(String[] args) {
        Pattern pattern;
        Scanner s = new Scanner(System.in);
        String password = s.nextLine();
        if (password.length() >= 12
                & password.matches(".*[0-9]+.*")
                & password.matches(".*[A-Z]+.*")
                & password.matches(".*[a-z]+.*")) {
            System.out.println("YES"); } else { System.out.println("NO"); }

    }}

