class Unit {
    String nameUnit ;

    public static void main(String[] args) {
        new Unit();
    }
    public Unit(){

        int x = 0;
        String names [] ={"1","2","3","4","5"};

        while (x<5){
           nameUnit = names[x];
            System.out.println("Unit : " + nameUnit);
            x++;
        }

    }
}

