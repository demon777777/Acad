class Box {

    double height;
    double width;
    double length;

    public double getVolume(){
        double result = height * width * length;
        return result;
}
//    public void getVolume(){
//        double result = height + width * length;
//        System.out.println(result);
//    }
}