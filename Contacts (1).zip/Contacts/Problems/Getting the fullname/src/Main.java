class User {
    /**
     * Вот Userкласс с двумя полями: firstNameи lastName.
     *
     * Реализуйте два установщика нулевой безопасности и один вычисляемый
     * получатель следующими способами:
     *
     * оба установщика должны принять и установить значение, если оно не является
     * nullпустой строкой "";
     * Получатель должен вернуть полное имя пользователя, объединяя firstNameи
     * lastNameиспользуя один пробел между ними. Если одна из частей не была
     * установлена, получатель должен вернуть другую часть без дополнительных
     * пробелов. Если обе части пусты, получатель должен вернуть слово "Unknown".
     */
    private String firstName;
    private String lastName;

    public User() {
        this.firstName = "888888888";
        this.lastName = "888888888888888888888888";
    }

    public void setFirstName(String firstName) {
       if (firstName != null){
           this.firstName = firstName;
       }
    }

    public void setLastName(String lastName) {
        if (lastName != null){
            this.lastName = lastName;
        }
    }

    /**
     * Получатель должен вернуть полное имя пользователя, объединяя firstNameи
     * lastName используя один пробел между ними. Если одна из частей не была
     * установлена, получатель должен вернуть другую часть без дополнительных
     * пробелов. Если обе части пусты, получатель должен вернуть слово "Unknown".
     */
    public String getFullName() {
        if(firstName != null && lastName != null){
            return firstName + " " + lastName;
        }if(firstName != null || lastName != null){
            return new String(); }
        return ""; // write your code here
       }
    public static void main(String[] args) {
        User user = new User();
        System.out.println(user.getFullName());
    }
}

