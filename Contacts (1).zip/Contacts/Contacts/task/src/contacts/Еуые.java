package contacts;

import java.util.ArrayList;

class S{

    public static void main(String[] args) {

        Integer a = 3;
        double d = -100;
        float f = -90;

        System.out.println(Math.abs(a));
        System.out.println(Math.abs(d));
        System.out.println(Math.abs(f));

    }
}