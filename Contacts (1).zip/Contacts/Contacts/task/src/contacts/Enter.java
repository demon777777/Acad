package contacts;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Enter {
    private String nameOfThePerson;
    private String surNameOfThePerson;
    static boolean matches = true;
    private String numberTelephon;
    private Scanner scanner;

    private void first_Name_Last_Name() {
        System.out.println("Enter the name of the person:");
        nameOfThePerson = scanner.nextLine();

        System.out.println("Enter the surname of the person:");
        surNameOfThePerson = scanner.nextLine();

        System.out.println("Enter the number:");
    }

    public void hasNumber() {
        System.out.println("Create a post!");
        if (scanner.hasNextLine()) {
            numberTelephon = scanner.nextLine();
            String y = getNumberTelephon();
            String reg = ".?[0-9]{1}.[0-9]{2,}.[0-9]{2,}.[0-9]{2,}.[A-Za-z0-9]{2,}";
            Pattern pattern = Pattern.compile(reg);
            Matcher matcher = pattern.matcher(y);
            matches = matcher.matches();
            System.out.println();
            if (matches == true) {
                System.out.println("Phone : " + y);
            } else {
                System.out.println("Incorrect input!");
                scanner.reset();
                hasNumber();
            }

        }
        System.out.println();

    }

    public String getNumberTelephon() {
        return numberTelephon;
    }

    public Enter() {
        scanner = new Scanner(System.in);
        try {
            if (numberTelephon == null) {
                hasNumber();
            }
            if (nameOfThePerson == null || surNameOfThePerson == null) {
                first_Name_Last_Name();
            }
            Thread.sleep(600);
            if (numberTelephon != null && nameOfThePerson != null && surNameOfThePerson != null) {
                System.out.println("A record created!");
                System.out.println();
                Thread.sleep(300);
                System.out.println("A Phone Book with a single record created!");
            } else {
                hasNumber();
                first_Name_Last_Name();
            }
        } catch (Exception e) {
        }
    }
}
